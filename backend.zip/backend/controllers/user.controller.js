
import * as userService from "../services/user.service.js";
import { validationResult } from "express-validator";
import userModel from "../models/user.model.js";
import redisClient from "../services/redis.service.js";
import * as sendMail from "../services/email.service.js";
import { generateOtp, getOtpHtml } from "../utils/utils.js";
import otpModel from "../models/otp.model.js";

// OTP configuration
const OTP_EXPIRY_SECONDS = 5 * 60;
const OTP_EXPIRY_MS = OTP_EXPIRY_SECONDS * 1000;

// Helper: Validate request
const validateRequest = (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        res.status(400).json({
            success: false,
            message: "Validation failed",
            errors: errors.array(),
        });

        return false;
    }

    return true;
};

// Helper: Send OTP
const sendOtpToEmail = async (email, subject, message) => {
    const otp = String(generateOtp());

    await otpModel.deleteMany({ email });

    await otpModel.create({
        email,
        otp,
        createdAt: new Date(),
    });

    const html = getOtpHtml(otp);

    // Assumed signature: sendMail(to, subject, html)
    await sendMail(email, subject, html);

    return true;
};

// Helper: Verify OTP
const verifyEmailOtp = async (email, otp) => {
    const otpRecord = await otpModel.findOne({
        email,
        otp: String(otp),
    });

    if (!otpRecord) {
        return false;
    }

    const createdAt = new Date(otpRecord.createdAt).getTime();

    if (Date.now() - createdAt > OTP_EXPIRY_MS) {
        await otpModel.deleteMany({ email });
        return false;
    }

    return otpRecord;
};

// ========================================
// CREATE USER
// ========================================

export const createUserController = async (req, res) => {
    if (!validateRequest(req, res)) return;

    try {
        const user = await userService.createUser(req.body);

        const token = await user.generateJWT();

        return res.status(201).json({
            success: true,
            message: "User created successfully",
            user: {
                _id: user._id,
                email: user.email,
            },
            token,
        });

    } catch (error) {
        console.error("Create User Error:", error);

        return res.status(400).json({
            success: false,
            message: error.message || "Unable to create user",
        });
    }
};

// ========================================
// LOGIN
// ========================================

export const loginController = async (req, res) => {
    if (!validateRequest(req, res)) return;

    try {
        const { email, password } = req.body;

        const user = await userModel
            .findOne({ email })
            .select("+password");

        if (!user) {
            return res.status(401).json({
                success: false,
                message: "Invalid email or password",
            });
        }

        const isMatch = await user.isValidPassword(password);

        if (!isMatch) {
            return res.status(401).json({
                success: false,
                message: "Invalid email or password",
            });
        }

        if (!user.isVerified) {
            return res.status(403).json({
                success: false,
                message: "Please verify your email first",
                code: "EMAIL_NOT_VERIFIED",
            });
        }

        const token = await user.generateJWT();

        return res.status(200).json({
            success: true,
            message: "Login successful",
            user: {
                _id: user._id,
                email: user.email,
            },
            token,
        });

    } catch (error) {
        console.error("Login Error:", error);

        return res.status(500).json({
            success: false,
            message: "Login failed",
        });
    }
};

// ========================================
// USER PROFILE
// ========================================

export const profileController = async (req, res) => {
    try {
        return res.status(200).json({
            success: true,
            user: req.user,
        });

    } catch (error) {
        console.error("Profile Error:", error);

        return res.status(500).json({
            success: false,
            message: "Unable to fetch profile",
        });
    }
};

// ========================================
// LOGOUT
// ========================================

export const loggoutController = async (req, res) => {
    try {
        const token =
            req.cookies?.token ||
            req.headers.authorization?.split(" ")[1];

        if (!token) {
            return res.status(401).json({
                success: false,
                message: "Authentication token not found",
            });
        }

        await redisClient.set(
            token,
            "logout",
            "EX",
            60 * 60 * 24
        );

        res.clearCookie("token");

        return res.status(200).json({
            success: true,
            message: "Logout successful",
        });

    } catch (error) {
        console.error("Redis Logout Error:", error);

        return res.status(500).json({
            success: false,
            message: "Logout failed",
        });
    }
};

// ========================================
// GET ALL USERS
// ========================================

export const getAllUsersController = async (req, res) => {
    try {
        const loggedInUser = await userModel.findOne({
            email: req.user.email,
        });

        if (!loggedInUser) {
            return res.status(404).json({
                success: false,
                message: "User not found",
            });
        }

        const allUsers = await userService.getAllUsers({
            userId: loggedInUser._id,
        });

        return res.status(200).json({
            success: true,
            users: allUsers,
        });

    } catch (error) {
        console.error("Get All Users Error:", error);

        return res.status(500).json({
            success: false,
            message: "Unable to fetch users",
        });
    }
};

// ========================================
// RESET PASSWORD
// ========================================

export const resetPassowrd = async (req, res) => {
    try {
        const { email, otp, newPassword } = req.body;

        if (!email || !otp || !newPassword) {
            return res.status(400).json({
                success: false,
                message: "Email, OTP and new password are required",
            });
        }

        if (newPassword.length < 8) {
            return res.status(400).json({
                success: false,
                message: "Password must contain at least 8 characters",
            });
        }

        const user = await userModel
            .findOne({ email })
            .select("+password");

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "Invalid password reset request",
            });
        }

        const otpRecord = await verifyEmailOtp(email, otp);

        if (!otpRecord) {
            return res.status(400).json({
                success: false,
                message: "Invalid or expired OTP",
            });
        }

        // Assign the new password.
        // The user model's pre-save hook should hash it.
        user.password = newPassword;

        await user.save();

        // OTP must be single-use.
        await otpModel.deleteMany({ email });

        return res.status(200).json({
            success: true,
            message: "Password reset successfully",
        });

    } catch (error) {
        console.error("Reset Password Error:", error);

        return res.status(500).json({
            success: false,
            message: "Unable to reset password",
        });
    }
};

// ========================================
// FORGOT PASSWORD
// ========================================

export const forgetPassword = async (req, res) => {
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(400).json({
                success: false,
                message: "Email is required",
            });
        }

        const user = await userModel.findOne({ email });

        // Avoid revealing whether an account exists.
        if (!user) {
            return res.status(200).json({
                success: true,
                message: "If an account exists, an OTP will be sent",
            });
        }

        await sendOtpToEmail(
            email,
            "Password Reset OTP",
            "Use this OTP to reset your password."
        );

        return res.status(200).json({
            success: true,
            message: "If an account exists, an OTP will be sent",
        });

    } catch (error) {
        console.error("Forgot Password Error:", error);

        return res.status(500).json({
            success: false,
            message: "Unable to process password reset request",
        });
    }
};

// ========================================
// RESEND OTP
// ========================================

export const resentOTP = async (req, res) => {
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(400).json({
                success: false,
                message: "Email is required",
            });
        }

        const user = await userModel.findOne({ email });

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found",
            });
        }

        if (user.isVerified) {
            return res.status(400).json({
                success: false,
                message: "Email is already verified",
            });
        }

        await sendOtpToEmail(
            email,
            "Email Verification OTP",
            "Use this OTP to verify your email address."
        );

        return res.status(200).json({
            success: true,
            message: "OTP sent successfully",
        });

    } catch (error) {
        console.error("Resend OTP Error:", error);

        return res.status(500).json({
            success: false,
            message: "Unable to resend OTP",
        });
    }
};

export const verifyEmail = async (req, res) => {
    try {
        const { email, otp } = req.body;

        if (!email || !otp) {
            return res.status(400).json({
                success: false,
                message: "Email and OTP are required",
            });
        }

        const otpRecord = await verifyEmailOtp(email, otp);

        if (!otpRecord) {
            return res.status(400).json({
                success: false,
                message: "Invalid or expired OTP",
            });
        }

        const user = await userModel.findOne({ email });

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found",
            });
        }

        user.isVerified = true;
        await user.save();

        await otpModel.deleteMany({ email });

        return res.status(200).json({
            success: true,
            message: "Email verified successfully",
        });

    } catch (error) {
        console.error("Verify Email Error:", error);

        return res.status(500).json({
            success: false,
            message: "Email verification failed",
        });
    }
};